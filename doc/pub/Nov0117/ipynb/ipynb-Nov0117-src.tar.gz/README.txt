This IPython notebook Nov0117.ipynb does not require any additional
programs.
