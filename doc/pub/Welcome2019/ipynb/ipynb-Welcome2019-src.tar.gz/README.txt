This IPython notebook Welcome2019.ipynb does not require any additional
programs.
