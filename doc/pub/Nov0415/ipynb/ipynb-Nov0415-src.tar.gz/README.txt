This IPython notebook Nov0415.ipynb does not require any additional
programs.
