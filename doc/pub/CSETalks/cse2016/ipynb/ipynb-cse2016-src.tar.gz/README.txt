This IPython notebook cse2016.ipynb does not require any additional
programs.
