This IPython notebook Feb0419.ipynb does not require any additional
programs.
