This IPython notebook TalkingPoints.ipynb does not require any additional
programs.
