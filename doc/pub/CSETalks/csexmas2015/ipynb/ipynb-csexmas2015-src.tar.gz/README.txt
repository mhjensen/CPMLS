This IPython notebook csexmas2015.ipynb does not require any additional
programs.
