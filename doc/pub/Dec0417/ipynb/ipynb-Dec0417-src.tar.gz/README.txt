This IPython notebook Dec0417.ipynb does not require any additional
programs.
