This IPython notebook Dec1515.ipynb does not require any additional
programs.
