This IPython notebook Welcome2023.ipynb does not require any additional
programs.
