This IPython notebook LearningAdmission.ipynb does not require any additional
programs.
