This IPython notebook Welcome.ipynb does not require any additional
programs.
