This IPython notebook Welcome2021.ipynb does not require any additional
programs.
