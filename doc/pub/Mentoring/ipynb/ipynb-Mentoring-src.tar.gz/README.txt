This IPython notebook Mentoring.ipynb does not require any additional
programs.
