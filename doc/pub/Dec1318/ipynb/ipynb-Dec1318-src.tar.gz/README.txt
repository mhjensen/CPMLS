This IPython notebook Dec1318.ipynb does not require any additional
programs.
