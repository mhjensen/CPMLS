This IPython notebook Welcome2020.ipynb does not require any additional
programs.
